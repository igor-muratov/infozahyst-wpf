﻿/* 
This code is a private property of Igor Muratov someguid@live.com 
Any usages without proper permission is forbidden

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE. */

using System.Collections.Generic;
using System.IO;
using System.Windows;
using System.Windows.Threading;
using LiveCharts;
using LiveCharts.Configurations;
using Sensors.Algo;
using Sensors.Models;
using Sensors.Properties;

namespace Sensors
{
    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App
    {
        protected override void OnStartup(StartupEventArgs e)
        {
            DispatcherUnhandledException += ApplicationOnDispatcherUnhandledException;

            base.OnStartup(e);

            // mapping settings 
            var mapper = Mappers.Xy<DataSample>()
                .X(model => model.Time.Ticks)
                .Y(model => model.Value);

            Charting.For<DataSample>(mapper);

            var onlineSensors = new List<Sensor>();
            foreach (var sensor in CreateDefaultSensors())
            {
                sensor.Start(Settings.Default.GenerationPeriod);
                onlineSensors.Add(sensor);
            }

            OnlineSensors = onlineSensors;
        }

        private void ApplicationOnDispatcherUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
        {
            var path = Path.Combine(System.AppDomain.CurrentDomain.BaseDirectory, "log.txt");
            File.AppendAllText(path, e.Exception.ToString());
            e.Handled = true;
        }

        public static IReadOnlyCollection<Sensor> OnlineSensors { get; private set; }

        public static IEnumerable<Sensor> CreateDefaultSensors()
        {
            var random = new NormalRandom();
            yield return new Sensor(Settings.Default.SensorBufferLen, random, Settings.Default.SensorMean, Settings.Default.SensorDeviation);
            yield return new Sensor(Settings.Default.SensorBufferLen, random, Settings.Default.SensorMean, Settings.Default.SensorDeviation);
            yield return new Sensor(Settings.Default.SensorBufferLen, random, Settings.Default.SensorMean, Settings.Default.SensorDeviation);
        }
    }
}
