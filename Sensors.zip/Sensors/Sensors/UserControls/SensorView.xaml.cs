﻿using System.Windows;
using Sensors.ViewModels;

namespace Sensors.UserControls
{
    /// <summary>
    /// Interaction logic for SensorView.xaml
    /// </summary>
    public partial class SensorView
    {
        public SensorView()
        {
            InitializeComponent();
        }

        private void SensorView_OnDataContextChanged(object sender, DependencyPropertyChangedEventArgs e)
        {
            // HACK: strock binding for view model does not work =(
            LineSeries.Stroke = (DataContext as SensorViewModel)?.Foreground;
        }
    }
}
