﻿using System.Collections.Generic;
using System.Diagnostics;

namespace Sensors.Models
{
    internal class DataSampleEqualityComparer : IComparer<DataSample>
    {
        public int Compare(DataSample x, DataSample y)
        {
            Debug.Assert(x != null, nameof(x) + " != null");
            Debug.Assert(y != null, nameof(y) + " != null");

            return x.Time.CompareTo(y.Time);
        }
    }
}