﻿using System;

namespace Sensors.Models
{
    public class DataSample
    {
        public DateTime Time { get; set; }
        public double Value { get; set; }
    }
}