﻿/* Private property

This code is private property of Igor Muratov someguid@live.com 
Any usages without proper permission is forbidden

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE. */

using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Diagnostics;
using System.Threading;
using Sensors.Algo;
using Sensors.Annotations;

namespace Sensors.Models
{
    /// <summary>
    /// Represents sensor hich fill data buffer
    /// if buffer does not have enought space data will be lost
    /// </summary>
    public class Sensor
    {
        private readonly int _bufferLen;
        private readonly NormalRandom _random;
        // ToDo: Implement
        private readonly double _mean;
        private readonly double _deviation;
        private ConcurrentQueue<DataSample> _data = new ConcurrentQueue<DataSample>();
        private readonly Timer _timer;

        public Sensor(int bufferLen, [NotNull] NormalRandom random, double mean, double deviation)
        {
            if (bufferLen <= 0) throw new ArgumentOutOfRangeException(nameof(bufferLen), "Buffer length must be greater when 0");
            _bufferLen = bufferLen;

            _random = random ?? throw new ArgumentNullException(nameof(random));
            _mean = mean;
            _deviation = deviation;
            _timer = new Timer(GenerateDataSample);
        }

        private void GenerateDataSample(object state)
        {
            if (_data.Count > _bufferLen)
            {
                _data.TryDequeue(out DataSample _);
            }

            // use only Z0
            _data.Enqueue(new DataSample
            {
                Time = DateTime.Now,
                Value = _random.NextDouble().Z0
            });
        }

        public void Start(TimeSpan period)
        {
            _timer.Change(TimeSpan.Zero, period);
        }

        public void Stop()
        {
            _timer.Change(Timeout.Infinite, Timeout.Infinite);
        }

        public IReadOnlyCollection<DataSample> SubstituteNewBuffer()
        {
            Debug.WriteLine($"Buffer replaced {DateTime.Now}");
            return Interlocked.Exchange(ref _data, new ConcurrentQueue<DataSample>());
        }
    }
}
