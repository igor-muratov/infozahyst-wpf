﻿using System;

namespace Sensors.Algo
{
    public static class MathPower
    {
        /// <summary>
        /// Convert 2 independent samples chosen from the uniform distribution on the unit interval (0, 1) to
        /// Z0 and Z1 which are independent random variables with a standard normal distribution.
        /// </summary>
        /// <param name="phi"></param>
        /// <param name="r"></param>
        /// <returns></returns>
        public static (double z0, double z1) BoxMullerBasicTransform(double phi, double r)
        {
            var sc = 2 * Math.PI * phi;
            var sqrt = Math.Sqrt(-2 * Math.Log(r));
            return (Math.Cos(sc) * sqrt, Math.Sign(sc) * sqrt);
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="x"></param>
        /// <param name="mean"></param>
        /// <param name="deviation"></param>
        /// <returns></returns>
        public static double StandartDistribution(double x, double mean, double deviation) => x * deviation + mean;
    }
}
