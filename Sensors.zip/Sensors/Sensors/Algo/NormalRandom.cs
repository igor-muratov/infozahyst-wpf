﻿using System;
using Sensors.Annotations;

namespace Sensors.Algo
{
    /// <summary>
    /// Method for generating pairs of independent, standard, normally distributed (zero expectation, unit variance) random numbers,
    /// given a source of uniformly distributed random numbers
    /// </summary>
    public class NormalRandom
    {
        private readonly Func<double> _random;

        public NormalRandom()
        {
            var random = new Random();
            _random = () => random.NextDouble();
        }

        public NormalRandom([NotNull] Func<double> randomGenerator)
        {
            _random = randomGenerator ?? throw new ArgumentNullException(nameof(randomGenerator));
        }

        /// <summary>
        /// Then Z0 and Z1 are independent random variables with a standard normal distribution
        /// </summary>
        /// <returns>(Z0, Z1)</returns>
        public (double Z0, double Z1) NextDouble()
        {
            var phi = _random();
            var r = _random();
            return MathPower.BoxMullerBasicTransform(phi, r);
        }
    }
}
