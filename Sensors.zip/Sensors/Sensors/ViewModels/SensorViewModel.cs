﻿/*
This code is a private property of Igor Muratov someguid@live.com 
Any usages without a proper permission is forbidden

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE. */

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Windows.Media;
using LiveCharts;
using Sensors.Annotations;
using Sensors.Models;
using Sensors.Properties;

namespace Sensors.ViewModels
{
    public class SensorViewModel : INotifyPropertyChanged
    {
        [NotNull]
        private readonly Sensor _sensor;
        private double _axisStep;
        private double _axisUnit;
        private double _axisMax;
        private double _axisMin;
        private Func<double, string> _dateTimeFormatter;
        private ChartValues<DataSample> _chartValues;
        private Brush _foreground;
        private string _title;
        public event PropertyChangedEventHandler PropertyChanged;

        public SensorViewModel([NotNull] string name, [NotNull] string title, [NotNull] Brush foreground, [NotNull] Sensor sensor)
        {
            Title = title ?? throw new ArgumentNullException(nameof(title));
            Foreground = foreground ?? throw new ArgumentNullException(nameof(foreground));
            Name = name ?? throw new ArgumentNullException(nameof(name));
            _sensor = sensor ?? throw new ArgumentNullException(nameof(sensor));

            DateTimeFormatter = value => new DateTime((long)value).ToString("mm:ss");
            AxisStep = AxisStep = TimeSpan.FromSeconds(1).Ticks;
            AxisUnit = TimeSpan.TicksPerSecond;
            SetupAxis(DateTime.Now.AddSeconds(-1), DateTime.Now);
            ChartValues = new ChartValues<DataSample>();
            TrackCurrent = true;
        }

        public Func<double, string> DateTimeFormatter
        {
            get => _dateTimeFormatter;
            set
            {
                if (Equals(value, _dateTimeFormatter)) return;
                _dateTimeFormatter = value;
                OnPropertyChanged();
            }
        }

        public bool TrackCurrent
        {
            get => _trackCurrent;
            set
            {
                if (value == _trackCurrent) return;
                _trackCurrent = value;
                OnPropertyChanged();
            }
        }

        public double AxisStep
        {
            get => _axisStep;
            set
            {
                if (value.Equals(_axisStep)) return;
                _axisStep = value;
                OnPropertyChanged();
            }
        }

        public double AxisUnit
        {
            get => _axisUnit;
            set
            {
                if (value.Equals(_axisUnit)) return;
                _axisUnit = value;
                OnPropertyChanged();
            }
        }

        public double AxisMax
        {
            get => _axisMax;
            set
            {
                _axisMax = value;
                OnPropertyChanged(nameof(AxisMax));
            }
        }

        public double AxisMin
        {
            get => _axisMin;
            set
            {
                _axisMin = value;
                OnPropertyChanged(nameof(AxisMin));
            }
        }

        public ChartValues<DataSample> ChartValues
        {
            get => _chartValues;
            set
            {
                if (Equals(value, _chartValues)) return;
                _chartValues = value;
                OnPropertyChanged();
            }
        }

        [NotNull]
        public string Title
        {
            get => _title;
            set
            {
                if (value == _title) return;
                _title = value;
                OnPropertyChanged();
            }
        }

        public string Name
        {
            get => _name;
            set
            {
                if (value == _name) return;
                _name = value;
                OnPropertyChanged();
            }
        }

        [NotNull]
        public Brush Foreground
        {
            get => _foreground;
            set
            {
                if (Equals(value, _foreground)) return;
                _foreground = value;
                OnPropertyChanged();
            }
        }

        private readonly SortedSet<DataSample> _points = new SortedSet<DataSample>(new DataSampleEqualityComparer());
        private bool _trackCurrent;
        private string _name;

        public void Update()
        {
            var now = DateTime.Now;
            var timeWindow = Settings.Default.PlotTimeWinow;
            var buffer = _sensor.SubstituteNewBuffer();

            _points.UnionWith(buffer);
            _points.RemoveWhere(p => now - p.Time > timeWindow);

            var max = TrackCurrent ? _points.Max.Time : new DateTime((long)AxisMax);
            var min = TrackCurrent ? _points.Max.Time.AddSeconds(-10) : new DateTime((long)AxisMin);

            var currentView = _points.GetViewBetween(
                new DataSample
                {
                    Time = min
                },
                new DataSample
                {
                    Time = max
                });


            // todo: config!
            SetupAxis(min, max);
            ChartValues.Clear();
            ChartValues.AddRange(currentView);
        }

        [NotifyPropertyChangedInvocator]
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        private void SetupAxis(DateTime min, DateTime max)
        {
            AxisMax = max.Ticks;
            AxisMin = min.Ticks;
        }
    }
}
