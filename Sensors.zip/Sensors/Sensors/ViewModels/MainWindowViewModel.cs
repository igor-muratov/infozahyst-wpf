﻿using System;
using System.ComponentModel;
using System.Diagnostics;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Windows;
using System.Windows.Data;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Threading;
using Sensors.Annotations;
using Sensors.Models;
using Sensors.Properties;

namespace Sensors.ViewModels
{
    public class MainWindowViewModel : INotifyPropertyChanged
    {
        private ICollectionView _sensors;
        private readonly DispatcherTimer _timer = new DispatcherTimer();
        private SensorViewModel _selectedSensor;

        public MainWindowViewModel()
        {
            // workaround for error during edit in Visual Studio
            if (DesignerProperties.GetIsInDesignMode(new DependencyObject())) return;

            _timer.Interval = Settings.Default.UpdatePlotInterval;
            _timer.Tick += UpdateSelectedSensor;
            _timer.Start();

            var wantedColors = new Brush[] { Brushes.Red, Brushes.LawnGreen, Brushes.CornflowerBlue };
            SensorViewModel CreateSensorVm(Sensor sensor, int i)
            {
                return new SensorViewModel($"Sensor #{i}", $"Details form for sensor #{i}", wantedColors[i % wantedColors.Length], sensor);
            }

            Sensors = CollectionViewSource.GetDefaultView(App.OnlineSensors.Select(CreateSensorVm));

            Select = new DelegateCommand(o => { SelectedSensor = (SensorViewModel) o; });
        }

        private void UpdateSelectedSensor(object sender, EventArgs e)
        {
            Debug.WriteLine("Enter update");
            SelectedSensor?.Update();
            Debug.WriteLine("Leave update");
        }

        public SensorViewModel SelectedSensor
        {
            get => _selectedSensor;
            set
            {
                if (Equals(value, _selectedSensor)) return;
                _selectedSensor = value;
                OnPropertyChanged();
            }
        }

        public ICollectionView Sensors
        {
            get => _sensors;
            set
            {
                if (Equals(value, _sensors)) return;
                _sensors = value;
                OnPropertyChanged(nameof(Sensors));
            }
        }

        public ICommand Select { get; set; }

        public event PropertyChangedEventHandler PropertyChanged;

        [NotifyPropertyChangedInvocator]
        protected virtual void OnPropertyChanged([CallerMemberName] string propertyName = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    }
}